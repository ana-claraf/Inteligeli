function showAlert() {
    alert("Obrigado por clicar! Mais informações em breve.");
}
